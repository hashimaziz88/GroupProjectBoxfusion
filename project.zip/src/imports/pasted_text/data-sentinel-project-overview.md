6. Project 3: SQL Data Security Visualiser
6.1 Project Title
DataSentinel: SQL Security and Anomaly Monitoring Platform

6.2 Problem Statement
Organizations often struggle to detect abnormal database activity early enough. Suspicious transaction spikes, unusual access patterns, or unauthorized data operations may go unnoticed without good observability. This project focuses on visualizing suspicious SQL-related behavior and surfacing security insights.

6.3 Goal
Build a platform that:

monitors database-related events or simulated transaction logs

identifies unusual patterns

visualizes security-relevant statistics

flags suspicious events for investigation

6.4 Primary Users
Database Administrator

Security Analyst

Operations Manager

Platform Administrator

6.5 Core Use Cases
Security Analyst
view suspicious transaction patterns

inspect anomaly alerts

filter by severity/date/user/database/table

drill into event history

DBA
monitor usage patterns

detect unusual query frequency

review permission-sensitive activity

inspect failed login or excessive write patterns

Operations Manager
see overall health metrics

review incident trends

export summary report

6.6 Functional Requirements
Monitoring Inputs
simulated SQL audit logs or activity events

transaction counts

login activity

data modification events

privileged action events

large data read/write events

Detection Features
anomaly flagging based on thresholds

detection of unusual read/write spikes

out-of-hours activity flagging

repeated failure patterns

risky privileged access patterns

Visualization
dashboard with alerts and trends

charts for reads/writes/failed access

top risky users or entities

anomaly timeline

severity-based incident queue

Incident Handling
mark reviewed/unreviewed

comment on alert

change incident status

export incident report

6.7 Non-Functional Requirements
clear dashboards

role-based views

filter/search capabilities

audit history

reasonable performance on moderate datasets

6.8 Suggested Database Entities
Users

MonitoredServers

Databases

Tables

ActivityEvents

SecurityAlerts

AlertRules

IncidentNotes

AlertStatusHistory

UserRiskProfile

6.9 Suggested AI Workflow
summarize suspicious patterns

explain likely reason for flagging

prioritize high-risk alerts

generate plain-language security summaries

suggest likely next investigation step

6.10 Key Challenge
The solution should avoid becoming a generic dashboard. It should provide security-oriented insight, not just data charts.

6.11 Minimum Viable Scope
ingest simulated SQL activity data

dashboard with anomaly indicators

rule-based suspicious event detection

alert review screen

AI-generated incident summary

6.12 Stretch Features
live streaming ingestion

server-wide monitoring view

anomaly scoring model

notification system

role-specific alert routing

6.13 Project-Specific Must-Haves
security-focused monitoring

anomaly flagging

useful dashboard and drill-down

alert lifecycle

AI-supported incident explanation

