import { createBrowserRouter } from "react-router";
import { DashboardLayout } from "./components/DashboardLayout";
import { DashboardPage } from "./pages/DashboardPage";
import { AlertsPage } from "./pages/AlertsPage";
import { ActivityEventsPage } from "./pages/ActivityEventsPage";
import { ServersPage } from "./pages/ServersPage";
import { AnalyticsPage } from "./pages/AnalyticsPage";
import { UsersPage } from "./pages/UsersPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: DashboardLayout,
    children: [
      { index: true, Component: DashboardPage },
      { path: "alerts", Component: AlertsPage },
      { path: "activity", Component: ActivityEventsPage },
      { path: "servers", Component: ServersPage },
      { path: "analytics", Component: AnalyticsPage },
      { path: "users", Component: UsersPage },
    ],
  },
]);