import { Layout, Menu, Button, Space, Badge, Avatar, Dropdown } from "antd";
import { Outlet, Link, useLocation } from "react-router";
import {
  DashboardOutlined,
  AlertOutlined,
  DatabaseOutlined,
  BarChartOutlined,
  TeamOutlined,
  UnorderedListOutlined,
  BellOutlined,
  UserOutlined,
  SettingOutlined,
  LogoutOutlined,
} from "@ant-design/icons";
import type { MenuProps } from "antd";

const { Header, Sider, Content } = Layout;

export function DashboardLayout() {
  const location = useLocation();

  const menuItems: MenuProps["items"] = [
    {
      key: "/",
      icon: <DashboardOutlined />,
      label: <Link to="/">Dashboard</Link>,
    },
    {
      key: "alerts",
      icon: <AlertOutlined />,
      label: <Link to="/alerts">Security Alerts</Link>,
    },
    {
      key: "activity",
      icon: <UnorderedListOutlined />,
      label: <Link to="/activity">Activity Events</Link>,
    },
    {
      key: "servers",
      icon: <DatabaseOutlined />,
      label: <Link to="/servers">Servers & Databases</Link>,
    },
    {
      key: "analytics",
      icon: <BarChartOutlined />,
      label: <Link to="/analytics">Analytics</Link>,
    },
    {
      key: "users",
      icon: <TeamOutlined />,
      label: <Link to="/users">User Risk Profiles</Link>,
    },
  ];

  const getSelectedKey = () => {
    if (location.pathname === "/") return "/";
    return location.pathname.substring(1);
  };

  const userMenuItems: MenuProps["items"] = [
    {
      key: "profile",
      icon: <UserOutlined />,
      label: "Profile",
    },
    {
      key: "settings",
      icon: <SettingOutlined />,
      label: "Settings",
    },
    {
      type: "divider",
    },
    {
      key: "logout",
      icon: <LogoutOutlined />,
      label: "Log out",
      danger: true,
    },
  ];

  return (
    <Layout style={{ minHeight: "100vh" }}>
      <Sider
        width={260}
        style={{
          background: "#0f172a",
          paddingTop: "16px",
        }}
      >
        <div style={{ padding: "0 24px", marginBottom: "32px" }}>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              marginBottom: "8px",
            }}
          >
            <div
              style={{
                width: "40px",
                height: "40px",
                background: "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)",
                borderRadius: "8px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "20px",
                color: "#ffffff",
              }}
            >
              🛡️
            </div>
            <div>
              <div
                style={{
                  color: "#ffffff",
                  fontSize: "18px",
                  fontWeight: 700,
                  letterSpacing: "-0.5px",
                }}
              >
                DataSentinel
              </div>
              <div
                style={{
                  color: "#64748b",
                  fontSize: "11px",
                }}
              >
                Security Monitoring
              </div>
            </div>
          </div>
        </div>

        <Menu
          mode="inline"
          selectedKeys={[getSelectedKey()]}
          items={menuItems}
          style={{
            background: "transparent",
            border: "none",
            color: "#94a3b8",
          }}
          theme="dark"
        />
      </Sider>

      <Layout>
        <Header
          style={{
            background: "#ffffff",
            padding: "0 32px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #e5e7eb",
            boxShadow: "0 1px 3px rgba(0,0,0,0.05)",
          }}
        >
          <div style={{ fontSize: "14px", color: "#64748b" }}>
            Last updated: {new Date().toLocaleString()}
          </div>

          <Space size="middle">
            <Badge count={5} size="small">
              <Button
                type="text"
                icon={<BellOutlined style={{ fontSize: "18px" }} />}
                style={{ color: "#64748b" }}
              />
            </Badge>

            <Dropdown menu={{ items: userMenuItems }} placement="bottomRight">
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  cursor: "pointer",
                }}
              >
                <Avatar
                  style={{ background: "#3b82f6" }}
                  icon={<UserOutlined />}
                />
                <div>
                  <div style={{ fontSize: "13px", fontWeight: 600 }}>
                    Security Analyst
                  </div>
                  <div style={{ fontSize: "11px", color: "#64748b" }}>
                    analyst@datasentinel.com
                  </div>
                </div>
              </div>
            </Dropdown>
          </Space>
        </Header>

        <Content
          style={{
            background: "#f8fafc",
            padding: "32px",
            minHeight: "calc(100vh - 64px)",
            overflow: "auto",
          }}
        >
          <Outlet />
        </Content>
      </Layout>
    </Layout>
  );
}
