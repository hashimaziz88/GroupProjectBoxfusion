import {
  Card,
  Row,
  Col,
  Statistic,
  Table,
  Tag,
  Timeline,
  Progress,
  Space,
  Button,
} from "antd";
import {
  ArrowUpOutlined,
  ArrowDownOutlined,
  WarningOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined,
} from "@ant-design/icons";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import type { ColumnsType } from "antd/es/table";

// Mock data for charts
const activityData = [
  { time: "00:00", reads: 120, writes: 45, failed: 2 },
  { time: "04:00", reads: 95, writes: 30, failed: 1 },
  { time: "08:00", reads: 380, writes: 150, failed: 5 },
  { time: "12:00", reads: 450, writes: 200, failed: 8 },
  { time: "16:00", reads: 520, writes: 180, failed: 12 },
  { time: "20:00", reads: 280, writes: 90, failed: 3 },
];

const anomalyTrendData = [
  { date: "Mar 10", anomalies: 12 },
  { date: "Mar 11", anomalies: 8 },
  { date: "Mar 12", anomalies: 15 },
  { date: "Mar 13", anomalies: 23 },
  { date: "Mar 14", anomalies: 18 },
  { date: "Mar 15", anomalies: 31 },
  { date: "Mar 16", anomalies: 27 },
];

interface AlertData {
  key: string;
  severity: "critical" | "high" | "medium" | "low";
  title: string;
  database: string;
  user: string;
  time: string;
  status: string;
}

const recentAlerts: AlertData[] = [
  {
    key: "1",
    severity: "critical",
    title: "Unusual data export volume detected",
    database: "production_db",
    user: "john.doe",
    time: "2 min ago",
    status: "unreviewed",
  },
  {
    key: "2",
    severity: "high",
    title: "Failed login attempts spike",
    database: "auth_db",
    user: "unknown",
    time: "15 min ago",
    status: "investigating",
  },
  {
    key: "3",
    severity: "medium",
    title: "Out-of-hours database access",
    database: "customer_db",
    user: "admin_user",
    time: "1 hour ago",
    status: "unreviewed",
  },
  {
    key: "4",
    severity: "high",
    title: "Privileged operation without approval",
    database: "production_db",
    user: "sys_admin",
    time: "3 hours ago",
    status: "unreviewed",
  },
];

const riskyUsers = [
  { user: "john.doe", riskScore: 87, events: 143, alerts: 12 },
  { user: "sys_admin", riskScore: 72, events: 98, alerts: 8 },
  { user: "db_operator", riskScore: 65, events: 234, alerts: 7 },
  { user: "admin_user", riskScore: 58, events: 67, alerts: 5 },
];

const alertColumns: ColumnsType<AlertData> = [
  {
    title: "Severity",
    dataIndex: "severity",
    key: "severity",
    width: 100,
    render: (severity: string) => {
      const colors = {
        critical: { color: "#dc2626", bg: "#fee2e2" },
        high: { color: "#ea580c", bg: "#ffedd5" },
        medium: { color: "#f59e0b", bg: "#fef3c7" },
        low: { color: "#3b82f6", bg: "#dbeafe" },
      };
      const style = colors[severity as keyof typeof colors];
      return (
        <Tag
          color={style.color}
          style={{
            background: style.bg,
            border: "none",
            fontWeight: 600,
            textTransform: "uppercase",
            fontSize: "11px",
          }}
        >
          {severity}
        </Tag>
      );
    },
  },
  {
    title: "Alert",
    dataIndex: "title",
    key: "title",
    render: (text, record) => (
      <div>
        <div style={{ fontWeight: 600, color: "#0f172a", marginBottom: "4px" }}>
          {text}
        </div>
        <div style={{ fontSize: "12px", color: "#64748b" }}>
          {record.database} • {record.user}
        </div>
      </div>
    ),
  },
  {
    title: "Time",
    dataIndex: "time",
    key: "time",
    width: 120,
  },
  {
    title: "Status",
    dataIndex: "status",
    key: "status",
    width: 120,
    render: (status: string) => (
      <Tag color={status === "unreviewed" ? "red" : "blue"}>{status}</Tag>
    ),
  },
];

export function DashboardPage() {
  return (
    <div>
      <div style={{ marginBottom: "24px" }}>
        <h1 style={{ fontSize: "28px", fontWeight: 700, marginBottom: "8px" }}>
          Security Dashboard
        </h1>
        <p style={{ color: "#64748b", fontSize: "14px" }}>
          Real-time monitoring of database security events and anomalies
        </p>
      </div>

      {/* Key Metrics */}
      <Row gutter={[16, 16]} style={{ marginBottom: "24px" }}>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Active Alerts"
              value={27}
              valueStyle={{ color: "#dc2626" }}
              prefix={<WarningOutlined />}
              suffix={
                <span style={{ fontSize: "14px", color: "#dc2626" }}>
                  <ArrowUpOutlined /> 23%
                </span>
              }
            />
            <div style={{ marginTop: "8px", fontSize: "12px", color: "#64748b" }}>
              5 critical require immediate attention
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Events Today"
              value={15234}
              valueStyle={{ color: "#3b82f6" }}
              suffix={
                <span style={{ fontSize: "14px", color: "#16a34a" }}>
                  <ArrowDownOutlined /> 8%
                </span>
              }
            />
            <div style={{ marginTop: "8px", fontSize: "12px", color: "#64748b" }}>
              12.3K reads, 2.9K writes
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Failed Operations"
              value={143}
              valueStyle={{ color: "#ea580c" }}
              prefix={<ClockCircleOutlined />}
              suffix={
                <span style={{ fontSize: "14px", color: "#dc2626" }}>
                  <ArrowUpOutlined /> 45%
                </span>
              }
            />
            <div style={{ marginTop: "8px", fontSize: "12px", color: "#64748b" }}>
              89 failed logins, 54 permission denied
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="System Health"
              value={94}
              valueStyle={{ color: "#16a34a" }}
              prefix={<CheckCircleOutlined />}
              suffix="%"
            />
            <div style={{ marginTop: "8px", fontSize: "12px", color: "#64748b" }}>
              All monitored servers operational
            </div>
          </Card>
        </Col>
      </Row>

      {/* Charts Row */}
      <Row gutter={[16, 16]} style={{ marginBottom: "24px" }}>
        <Col xs={24} lg={16}>
          <Card title="Database Activity (Last 24 Hours)" styles={{ body: { paddingTop: "16px" } }}>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="time" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="reads"
                  stackId="1"
                  stroke="#3b82f6"
                  fill="#3b82f6"
                  fillOpacity={0.6}
                  name="Read Operations"
                />
                <Area
                  type="monotone"
                  dataKey="writes"
                  stackId="1"
                  stroke="#8b5cf6"
                  fill="#8b5cf6"
                  fillOpacity={0.6}
                  name="Write Operations"
                />
                <Area
                  type="monotone"
                  dataKey="failed"
                  stackId="2"
                  stroke="#dc2626"
                  fill="#dc2626"
                  fillOpacity={0.8}
                  name="Failed Operations"
                />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </Col>

        <Col xs={24} lg={8}>
          <Card title="Anomaly Trend" styles={{ body: { paddingTop: "16px" } }}>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={anomalyTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip />
                <Bar dataKey="anomalies" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </Col>
      </Row>

      {/* Alerts and Risky Users */}
      <Row gutter={[16, 16]} style={{ marginBottom: "24px" }}>
        <Col xs={24} lg={16}>
          <Card
            title="Recent Security Alerts"
            extra={
              <Button type="primary" size="small">
                View All
              </Button>
            }
            styles={{ body: { padding: 0 } }}
          >
            <Table
              columns={alertColumns}
              dataSource={recentAlerts}
              pagination={false}
              size="small"
            />
          </Card>
        </Col>

        <Col xs={24} lg={8}>
          <Card title="Top Risky Users" styles={{ body: { paddingTop: "16px" } }}>
            <Space direction="vertical" style={{ width: "100%" }} size="middle">
              {riskyUsers.map((user) => (
                <div key={user.user}>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      marginBottom: "8px",
                    }}
                  >
                    <span style={{ fontWeight: 600 }}>{user.user}</span>
                    <span
                      style={{
                        color: user.riskScore > 70 ? "#dc2626" : "#f59e0b",
                        fontWeight: 600,
                      }}
                    >
                      {user.riskScore}
                    </span>
                  </div>
                  <Progress
                    percent={user.riskScore}
                    strokeColor={
                      user.riskScore > 70
                        ? "#dc2626"
                        : user.riskScore > 60
                        ? "#f59e0b"
                        : "#3b82f6"
                    }
                    showInfo={false}
                    size="small"
                  />
                  <div
                    style={{
                      fontSize: "12px",
                      color: "#64748b",
                      marginTop: "4px",
                    }}
                  >
                    {user.events} events • {user.alerts} alerts
                  </div>
                </div>
              ))}
            </Space>
          </Card>
        </Col>
      </Row>

      {/* Recent Activity Timeline */}
      <Card title="Recent Activity Timeline">
        <Timeline
          items={[
            {
              color: "red",
              children: (
                <div>
                  <div style={{ fontWeight: 600 }}>
                    Critical: Bulk data export detected
                  </div>
                  <div style={{ fontSize: "12px", color: "#64748b" }}>
                    User: john.doe • Database: production_db • 2 minutes ago
                  </div>
                  <div style={{ fontSize: "12px", color: "#64748b", marginTop: "4px" }}>
                    AI Analysis: Unusual volume of data exported (2.3GB) outside
                    business hours. Recommend immediate investigation.
                  </div>
                </div>
              ),
            },
            {
              color: "orange",
              children: (
                <div>
                  <div style={{ fontWeight: 600 }}>
                    High: Multiple failed authentication attempts
                  </div>
                  <div style={{ fontSize: "12px", color: "#64748b" }}>
                    Source IP: 192.168.1.45 • Database: auth_db • 15 minutes ago
                  </div>
                </div>
              ),
            },
            {
              color: "blue",
              children: (
                <div>
                  <div style={{ fontWeight: 600 }}>
                    Info: Scheduled maintenance completed
                  </div>
                  <div style={{ fontSize: "12px", color: "#64748b" }}>
                    Server: db-prod-01 • 1 hour ago
                  </div>
                </div>
              ),
            },
            {
              color: "orange",
              children: (
                <div>
                  <div style={{ fontWeight: 600 }}>
                    Medium: Out-of-hours database access
                  </div>
                  <div style={{ fontSize: "12px", color: "#64748b" }}>
                    User: admin_user • Database: customer_db • 2 hours ago
                  </div>
                </div>
              ),
            },
          ]}
        />
      </Card>
    </div>
  );
}
