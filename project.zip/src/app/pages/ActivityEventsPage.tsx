import { useState } from "react";
import {
  Card,
  Table,
  Tag,
  Button,
  Space,
  Select,
  Input,
  DatePicker,
  Tabs,
  Statistic,
  Row,
  Col,
} from "antd";
import {
  SearchOutlined,
  FilterOutlined,
  DatabaseOutlined,
  LockOutlined,
  EditOutlined,
  FileTextOutlined,
} from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";

const { RangePicker } = DatePicker;

interface ActivityEvent {
  key: string;
  id: string;
  eventType: "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "LOGIN" | "LOGOUT" | "DDL" | "GRANT";
  database: string;
  table: string;
  user: string;
  timestamp: string;
  duration: number;
  rowsAffected: number;
  queryPreview: string;
  ipAddress: string;
  status: "success" | "failed";
}

const mockEvents: ActivityEvent[] = [
  {
    key: "1",
    id: "EVT-20240316-145623",
    eventType: "SELECT",
    database: "production_db",
    table: "customers",
    user: "john.doe",
    timestamp: "2024-03-16 14:56:23",
    duration: 234,
    rowsAffected: 15000,
    queryPreview: "SELECT * FROM customers WHERE created_date > '2024-01-01'",
    ipAddress: "192.168.1.100",
    status: "success",
  },
  {
    key: "2",
    id: "EVT-20240316-145245",
    eventType: "INSERT",
    database: "production_db",
    table: "orders",
    user: "api_service",
    timestamp: "2024-03-16 14:52:45",
    duration: 45,
    rowsAffected: 1,
    queryPreview: "INSERT INTO orders (customer_id, total, status) VALUES (...)",
    ipAddress: "10.0.0.5",
    status: "success",
  },
  {
    key: "3",
    id: "EVT-20240316-145122",
    eventType: "UPDATE",
    database: "customer_db",
    table: "user_profiles",
    user: "admin_user",
    timestamp: "2024-03-16 14:51:22",
    duration: 89,
    rowsAffected: 234,
    queryPreview: "UPDATE user_profiles SET last_login = NOW() WHERE ...",
    ipAddress: "192.168.1.25",
    status: "success",
  },
  {
    key: "4",
    id: "EVT-20240316-145001",
    eventType: "DELETE",
    database: "production_db",
    table: "temp_data",
    user: "sys_admin",
    timestamp: "2024-03-16 14:50:01",
    duration: 567,
    rowsAffected: 5000,
    queryPreview: "DELETE FROM temp_data WHERE created_at < '2024-03-01'",
    ipAddress: "192.168.1.10",
    status: "success",
  },
  {
    key: "5",
    id: "EVT-20240316-144823",
    eventType: "LOGIN",
    database: "auth_db",
    table: "N/A",
    user: "john.doe",
    timestamp: "2024-03-16 14:48:23",
    duration: 0,
    rowsAffected: 0,
    queryPreview: "N/A",
    ipAddress: "192.168.1.100",
    status: "success",
  },
  {
    key: "6",
    id: "EVT-20240316-144715",
    eventType: "LOGIN",
    database: "auth_db",
    table: "N/A",
    user: "unknown",
    timestamp: "2024-03-16 14:47:15",
    duration: 0,
    rowsAffected: 0,
    queryPreview: "N/A",
    ipAddress: "203.45.67.89",
    status: "failed",
  },
  {
    key: "7",
    id: "EVT-20240316-144512",
    eventType: "DDL",
    database: "production_db",
    table: "analytics_temp",
    user: "sys_admin",
    timestamp: "2024-03-16 14:45:12",
    duration: 123,
    rowsAffected: 0,
    queryPreview: "DROP TABLE analytics_temp",
    ipAddress: "192.168.1.10",
    status: "success",
  },
  {
    key: "8",
    id: "EVT-20240316-144234",
    eventType: "GRANT",
    database: "auth_db",
    table: "N/A",
    user: "db_admin",
    timestamp: "2024-03-16 14:42:34",
    duration: 12,
    rowsAffected: 0,
    queryPreview: "GRANT SELECT ON auth_db.* TO 'new_analyst'@'%'",
    ipAddress: "192.168.1.15",
    status: "success",
  },
];

export function ActivityEventsPage() {
  const [selectedEventType, setSelectedEventType] = useState<string>("all");

  const columns: ColumnsType<ActivityEvent> = [
    {
      title: "Event ID",
      dataIndex: "id",
      key: "id",
      width: 180,
      render: (text) => (
        <span style={{ fontSize: "11px", fontFamily: "monospace", color: "#64748b" }}>
          {text}
        </span>
      ),
    },
    {
      title: "Type",
      dataIndex: "eventType",
      key: "eventType",
      width: 90,
      filters: [
        { text: "SELECT", value: "SELECT" },
        { text: "INSERT", value: "INSERT" },
        { text: "UPDATE", value: "UPDATE" },
        { text: "DELETE", value: "DELETE" },
        { text: "LOGIN", value: "LOGIN" },
        { text: "DDL", value: "DDL" },
        { text: "GRANT", value: "GRANT" },
      ],
      onFilter: (value, record) => record.eventType === value,
      render: (type: string) => {
        const colors: Record<string, string> = {
          SELECT: "blue",
          INSERT: "green",
          UPDATE: "orange",
          DELETE: "red",
          LOGIN: "purple",
          LOGOUT: "purple",
          DDL: "magenta",
          GRANT: "cyan",
        };
        return (
          <Tag color={colors[type]} style={{ fontSize: "11px", fontWeight: 600 }}>
            {type}
          </Tag>
        );
      },
    },
    {
      title: "Database / Table",
      key: "dbTable",
      render: (_, record) => (
        <div>
          <div style={{ fontWeight: 600, color: "#0f172a" }}>{record.database}</div>
          <div style={{ fontSize: "12px", color: "#64748b" }}>{record.table}</div>
        </div>
      ),
    },
    {
      title: "User",
      dataIndex: "user",
      key: "user",
      width: 120,
      render: (user: string) => <span style={{ fontWeight: 500 }}>{user}</span>,
    },
    {
      title: "Query Preview",
      dataIndex: "queryPreview",
      key: "queryPreview",
      ellipsis: true,
      render: (query: string) => (
        <span style={{ fontSize: "12px", fontFamily: "monospace", color: "#475569" }}>
          {query}
        </span>
      ),
    },
    {
      title: "Rows",
      dataIndex: "rowsAffected",
      key: "rowsAffected",
      width: 80,
      align: "right",
      sorter: (a, b) => a.rowsAffected - b.rowsAffected,
      render: (rows: number) => (
        <span style={{ fontWeight: 600 }}>{rows.toLocaleString()}</span>
      ),
    },
    {
      title: "Duration (ms)",
      dataIndex: "duration",
      key: "duration",
      width: 110,
      align: "right",
      sorter: (a, b) => a.duration - b.duration,
      render: (duration: number) => (
        <span
          style={{
            color: duration > 500 ? "#dc2626" : duration > 200 ? "#f59e0b" : "#16a34a",
            fontWeight: 600,
          }}
        >
          {duration}
        </span>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 90,
      filters: [
        { text: "Success", value: "success" },
        { text: "Failed", value: "failed" },
      ],
      onFilter: (value, record) => record.status === value,
      render: (status: string) => (
        <Tag color={status === "success" ? "green" : "red"}>
          {status === "success" ? "✓" : "✗"}
        </Tag>
      ),
    },
    {
      title: "Timestamp",
      dataIndex: "timestamp",
      key: "timestamp",
      width: 160,
      sorter: (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime(),
    },
  ];

  const eventTypeStats = {
    total: mockEvents.length,
    read: mockEvents.filter((e) => e.eventType === "SELECT").length,
    write: mockEvents.filter((e) => ["INSERT", "UPDATE", "DELETE"].includes(e.eventType))
      .length,
    auth: mockEvents.filter((e) => ["LOGIN", "LOGOUT"].includes(e.eventType)).length,
    privileged: mockEvents.filter((e) => ["DDL", "GRANT"].includes(e.eventType)).length,
  };

  return (
    <div>
      <div style={{ marginBottom: "24px" }}>
        <h1 style={{ fontSize: "28px", fontWeight: 700, marginBottom: "8px" }}>
          Activity Events
        </h1>
        <p style={{ color: "#64748b", fontSize: "14px" }}>
          Detailed audit log of all database operations and access events
        </p>
      </div>

      {/* Event Statistics */}
      <Row gutter={[16, 16]} style={{ marginBottom: "24px" }}>
        <Col xs={24} sm={12} md={6} lg={4}>
          <Card>
            <Statistic
              title="Total Events"
              value={eventTypeStats.total}
              prefix={<FileTextOutlined />}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6} lg={4}>
          <Card>
            <Statistic
              title="Read Ops"
              value={eventTypeStats.read}
              prefix={<DatabaseOutlined />}
              valueStyle={{ color: "#3b82f6" }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6} lg={4}>
          <Card>
            <Statistic
              title="Write Ops"
              value={eventTypeStats.write}
              prefix={<EditOutlined />}
              valueStyle={{ color: "#8b5cf6" }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6} lg={4}>
          <Card>
            <Statistic
              title="Auth Events"
              value={eventTypeStats.auth}
              prefix={<LockOutlined />}
              valueStyle={{ color: "#10b981" }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} md={6} lg={4}>
          <Card>
            <Statistic
              title="Privileged Ops"
              value={eventTypeStats.privileged}
              prefix={<LockOutlined />}
              valueStyle={{ color: "#f59e0b" }}
            />
          </Card>
        </Col>
      </Row>

      {/* Filters */}
      <Card style={{ marginBottom: "24px" }}>
        <Space wrap style={{ width: "100%" }}>
          <Input
            placeholder="Search events..."
            prefix={<SearchOutlined />}
            style={{ width: 250 }}
          />
          <Select
            defaultValue="all"
            style={{ width: 180 }}
            onChange={setSelectedEventType}
          >
            <Select.Option value="all">All Event Types</Select.Option>
            <Select.Option value="SELECT">SELECT</Select.Option>
            <Select.Option value="INSERT">INSERT</Select.Option>
            <Select.Option value="UPDATE">UPDATE</Select.Option>
            <Select.Option value="DELETE">DELETE</Select.Option>
            <Select.Option value="LOGIN">LOGIN/LOGOUT</Select.Option>
            <Select.Option value="DDL">DDL Operations</Select.Option>
            <Select.Option value="GRANT">Permission Changes</Select.Option>
          </Select>
          <Select defaultValue="all" style={{ width: 180 }}>
            <Select.Option value="all">All Databases</Select.Option>
            <Select.Option value="production_db">production_db</Select.Option>
            <Select.Option value="auth_db">auth_db</Select.Option>
            <Select.Option value="customer_db">customer_db</Select.Option>
          </Select>
          <Select defaultValue="all" style={{ width: 150 }}>
            <Select.Option value="all">All Users</Select.Option>
            <Select.Option value="john.doe">john.doe</Select.Option>
            <Select.Option value="sys_admin">sys_admin</Select.Option>
            <Select.Option value="api_service">api_service</Select.Option>
          </Select>
          <RangePicker showTime />
          <Button icon={<FilterOutlined />}>Advanced Filters</Button>
        </Space>
      </Card>

      {/* Events Table */}
      <Card>
        <Tabs
          defaultActiveKey="all"
          items={[
            {
              key: "all",
              label: "All Events",
              children: (
                <Table
                  columns={columns}
                  dataSource={mockEvents}
                  pagination={{ pageSize: 20, showSizeChanger: true }}
                  scroll={{ x: 1400 }}
                  size="small"
                />
              ),
            },
            {
              key: "suspicious",
              label: (
                <span>
                  Suspicious Activity <Tag color="red">3</Tag>
                </span>
              ),
              children: (
                <Table
                  columns={columns}
                  dataSource={mockEvents.filter(
                    (e) =>
                      e.status === "failed" ||
                      e.rowsAffected > 1000 ||
                      e.eventType === "DELETE"
                  )}
                  pagination={{ pageSize: 20 }}
                  scroll={{ x: 1400 }}
                  size="small"
                />
              ),
            },
            {
              key: "failed",
              label: (
                <span>
                  Failed Events <Tag color="orange">1</Tag>
                </span>
              ),
              children: (
                <Table
                  columns={columns}
                  dataSource={mockEvents.filter((e) => e.status === "failed")}
                  pagination={{ pageSize: 20 }}
                  scroll={{ x: 1400 }}
                  size="small"
                />
              ),
            },
          ]}
        />
      </Card>
    </div>
  );
}
