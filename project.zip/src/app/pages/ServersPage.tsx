import { Card, Row, Col, Table, Tag, Progress, Space, Badge, Statistic } from "antd";
import {
  DatabaseOutlined,
  CheckCircleOutlined,
  WarningOutlined,
  ClockCircleOutlined,
} from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";

interface Server {
  key: string;
  name: string;
  host: string;
  status: "online" | "warning" | "offline";
  databases: number;
  cpu: number;
  memory: number;
  connections: number;
  maxConnections: number;
  uptime: string;
  version: string;
}

interface Database {
  key: string;
  name: string;
  server: string;
  size: string;
  tables: number;
  activeConnections: number;
  queriesPerSec: number;
  lastBackup: string;
  status: "healthy" | "warning";
}

const servers: Server[] = [
  {
    key: "1",
    name: "db-prod-01",
    host: "10.0.1.10",
    status: "online",
    databases: 5,
    cpu: 45,
    memory: 62,
    connections: 78,
    maxConnections: 150,
    uptime: "45 days",
    version: "PostgreSQL 15.2",
  },
  {
    key: "2",
    name: "db-prod-02",
    host: "10.0.1.11",
    status: "online",
    databases: 3,
    cpu: 32,
    memory: 58,
    connections: 45,
    maxConnections: 150,
    uptime: "45 days",
    version: "PostgreSQL 15.2",
  },
  {
    key: "3",
    name: "db-analytics-01",
    host: "10.0.2.10",
    status: "warning",
    databases: 2,
    cpu: 78,
    memory: 89,
    connections: 132,
    maxConnections: 150,
    uptime: "12 days",
    version: "PostgreSQL 14.7",
  },
  {
    key: "4",
    name: "db-staging-01",
    host: "10.0.3.10",
    status: "online",
    databases: 4,
    cpu: 23,
    memory: 34,
    connections: 12,
    maxConnections: 100,
    uptime: "89 days",
    version: "PostgreSQL 15.2",
  },
];

const databases: Database[] = [
  {
    key: "1",
    name: "production_db",
    server: "db-prod-01",
    size: "45.2 GB",
    tables: 127,
    activeConnections: 34,
    queriesPerSec: 450,
    lastBackup: "2 hours ago",
    status: "healthy",
  },
  {
    key: "2",
    name: "auth_db",
    server: "db-prod-01",
    size: "3.8 GB",
    tables: 15,
    activeConnections: 12,
    queriesPerSec: 89,
    lastBackup: "2 hours ago",
    status: "healthy",
  },
  {
    key: "3",
    name: "customer_db",
    server: "db-prod-02",
    size: "128.5 GB",
    tables: 234,
    activeConnections: 23,
    queriesPerSec: 678,
    lastBackup: "1 hour ago",
    status: "healthy",
  },
  {
    key: "4",
    name: "analytics_db",
    server: "db-analytics-01",
    size: "567.3 GB",
    tables: 89,
    activeConnections: 89,
    queriesPerSec: 1234,
    lastBackup: "4 hours ago",
    status: "warning",
  },
  {
    key: "5",
    name: "temp_db",
    server: "db-prod-01",
    size: "2.1 GB",
    tables: 8,
    activeConnections: 3,
    queriesPerSec: 12,
    lastBackup: "12 hours ago",
    status: "healthy",
  },
];

export function ServersPage() {
  const serverColumns: ColumnsType<Server> = [
    {
      title: "Server",
      key: "server",
      render: (_, record) => (
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <Badge
              status={
                record.status === "online"
                  ? "success"
                  : record.status === "warning"
                  ? "warning"
                  : "error"
              }
            />
            <span style={{ fontWeight: 600 }}>{record.name}</span>
          </div>
          <div style={{ fontSize: "12px", color: "#64748b", marginTop: "2px" }}>
            {record.host}
          </div>
        </div>
      ),
    },
    {
      title: "Version",
      dataIndex: "version",
      key: "version",
    },
    {
      title: "Databases",
      dataIndex: "databases",
      key: "databases",
      align: "center",
      render: (count: number) => (
        <Tag icon={<DatabaseOutlined />} color="blue">
          {count}
        </Tag>
      ),
    },
    {
      title: "CPU Usage",
      dataIndex: "cpu",
      key: "cpu",
      render: (cpu: number) => (
        <div>
          <Progress
            percent={cpu}
            strokeColor={cpu > 70 ? "#dc2626" : cpu > 50 ? "#f59e0b" : "#16a34a"}
            size="small"
            format={(percent) => `${percent}%`}
          />
        </div>
      ),
    },
    {
      title: "Memory",
      dataIndex: "memory",
      key: "memory",
      render: (memory: number) => (
        <div>
          <Progress
            percent={memory}
            strokeColor={memory > 80 ? "#dc2626" : memory > 60 ? "#f59e0b" : "#16a34a"}
            size="small"
            format={(percent) => `${percent}%`}
          />
        </div>
      ),
    },
    {
      title: "Connections",
      key: "connections",
      render: (_, record) => (
        <div>
          <div style={{ fontWeight: 600 }}>
            {record.connections} / {record.maxConnections}
          </div>
          <Progress
            percent={(record.connections / record.maxConnections) * 100}
            showInfo={false}
            strokeColor={
              record.connections / record.maxConnections > 0.8
                ? "#dc2626"
                : record.connections / record.maxConnections > 0.6
                ? "#f59e0b"
                : "#16a34a"
            }
            size="small"
          />
        </div>
      ),
    },
    {
      title: "Uptime",
      dataIndex: "uptime",
      key: "uptime",
    },
  ];

  const databaseColumns: ColumnsType<Database> = [
    {
      title: "Database",
      key: "database",
      render: (_, record) => (
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <DatabaseOutlined style={{ color: "#3b82f6" }} />
            <span style={{ fontWeight: 600 }}>{record.name}</span>
          </div>
          <div style={{ fontSize: "12px", color: "#64748b", marginTop: "2px" }}>
            Server: {record.server}
          </div>
        </div>
      ),
    },
    {
      title: "Size",
      dataIndex: "size",
      key: "size",
      sorter: (a, b) => parseFloat(a.size) - parseFloat(b.size),
    },
    {
      title: "Tables",
      dataIndex: "tables",
      key: "tables",
      align: "right",
      sorter: (a, b) => a.tables - b.tables,
    },
    {
      title: "Active Connections",
      dataIndex: "activeConnections",
      key: "activeConnections",
      align: "right",
      sorter: (a, b) => a.activeConnections - b.activeConnections,
      render: (count: number) => <span style={{ fontWeight: 600 }}>{count}</span>,
    },
    {
      title: "Queries/sec",
      dataIndex: "queriesPerSec",
      key: "queriesPerSec",
      align: "right",
      sorter: (a, b) => a.queriesPerSec - b.queriesPerSec,
      render: (qps: number) => (
        <span
          style={{
            fontWeight: 600,
            color: qps > 1000 ? "#f59e0b" : "#16a34a",
          }}
        >
          {qps.toLocaleString()}
        </span>
      ),
    },
    {
      title: "Last Backup",
      dataIndex: "lastBackup",
      key: "lastBackup",
      render: (backup: string) => (
        <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
          <ClockCircleOutlined style={{ fontSize: "12px", color: "#64748b" }} />
          <span>{backup}</span>
        </div>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status: string) => (
        <Tag
          icon={status === "healthy" ? <CheckCircleOutlined /> : <WarningOutlined />}
          color={status === "healthy" ? "green" : "orange"}
        >
          {status}
        </Tag>
      ),
    },
  ];

  const totalDatabases = databases.length;
  const healthyDatabases = databases.filter((db) => db.status === "healthy").length;
  const totalServers = servers.length;
  const onlineServers = servers.filter((s) => s.status === "online").length;

  return (
    <div>
      <div style={{ marginBottom: "24px" }}>
        <h1 style={{ fontSize: "28px", fontWeight: 700, marginBottom: "8px" }}>
          Servers & Databases
        </h1>
        <p style={{ color: "#64748b", fontSize: "14px" }}>
          Monitor and manage all database servers and instances
        </p>
      </div>

      {/* Overview Statistics */}
      <Row gutter={[16, 16]} style={{ marginBottom: "24px" }}>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Total Servers"
              value={totalServers}
              prefix={<DatabaseOutlined />}
              suffix={
                <span style={{ fontSize: "14px", color: "#16a34a" }}>
                  {onlineServers} online
                </span>
              }
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Total Databases"
              value={totalDatabases}
              prefix={<DatabaseOutlined />}
              suffix={
                <span style={{ fontSize: "14px", color: "#16a34a" }}>
                  {healthyDatabases} healthy
                </span>
              }
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Total Storage"
              value="746.9"
              suffix="GB"
              valueStyle={{ color: "#3b82f6" }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Active Connections"
              value={161}
              valueStyle={{ color: "#8b5cf6" }}
            />
          </Card>
        </Col>
      </Row>

      {/* Servers Table */}
      <Card title="Monitored Servers" style={{ marginBottom: "24px" }}>
        <Table columns={serverColumns} dataSource={servers} pagination={false} />
      </Card>

      {/* Databases Table */}
      <Card title="Databases">
        <Table
          columns={databaseColumns}
          dataSource={databases}
          pagination={{ pageSize: 10 }}
        />
      </Card>
    </div>
  );
}
