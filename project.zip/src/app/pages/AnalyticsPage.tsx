import { Card, Row, Col, Select, DatePicker, Space, Button, Statistic, Table } from "antd";
import {
  DownloadOutlined,
  ArrowUpOutlined,
  ArrowDownOutlined,
} from "@ant-design/icons";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import type { ColumnsType } from "antd/es/table";

const { RangePicker } = DatePicker;

// Mock data
const alertTrendData = [
  { month: "Oct", critical: 12, high: 23, medium: 45, low: 67 },
  { month: "Nov", critical: 15, high: 28, medium: 52, low: 71 },
  { month: "Dec", critical: 9, high: 21, medium: 38, low: 59 },
  { month: "Jan", critical: 18, high: 34, medium: 61, low: 83 },
  { month: "Feb", critical: 14, high: 29, medium: 48, low: 72 },
  { month: "Mar", critical: 21, high: 38, medium: 67, low: 89 },
];

const eventTypeDistribution = [
  { name: "SELECT", value: 12450, color: "#3b82f6" },
  { name: "INSERT", value: 3420, color: "#10b981" },
  { name: "UPDATE", value: 2890, color: "#f59e0b" },
  { name: "DELETE", value: 450, color: "#dc2626" },
  { name: "DDL", value: 120, color: "#8b5cf6" },
  { name: "GRANT", value: 45, color: "#06b6d4" },
];

const databaseActivityData = [
  { hour: "00:00", production_db: 120, auth_db: 45, customer_db: 89 },
  { hour: "04:00", production_db: 95, auth_db: 32, customer_db: 67 },
  { hour: "08:00", production_db: 380, auth_db: 150, customer_db: 234 },
  { hour: "12:00", production_db: 450, auth_db: 200, customer_db: 312 },
  { hour: "16:00", production_db: 520, auth_db: 180, customer_db: 289 },
  { hour: "20:00", production_db: 280, auth_db: 90, customer_db: 156 },
];

const topQueriesData = [
  {
    key: "1",
    query: "SELECT * FROM customers WHERE...",
    database: "production_db",
    executions: 15234,
    avgDuration: 234,
    totalTime: "59.2 min",
  },
  {
    key: "2",
    query: "UPDATE user_profiles SET...",
    database: "customer_db",
    executions: 8923,
    avgDuration: 89,
    totalTime: "13.2 min",
  },
  {
    key: "3",
    query: "INSERT INTO orders VALUES...",
    database: "production_db",
    executions: 6745,
    avgDuration: 45,
    totalTime: "5.1 min",
  },
  {
    key: "4",
    query: "SELECT COUNT(*) FROM analytics...",
    database: "analytics_db",
    executions: 4523,
    avgDuration: 567,
    totalTime: "42.8 min",
  },
];

const incidentResolutionData = [
  { week: "Week 1", resolved: 23, investigating: 5, unreviewed: 8 },
  { week: "Week 2", resolved: 28, investigating: 4, unreviewed: 6 },
  { week: "Week 3", resolved: 19, investigating: 7, unreviewed: 12 },
  { week: "Week 4", resolved: 31, investigating: 3, unreviewed: 9 },
];

export function AnalyticsPage() {
  const queryColumns: ColumnsType<typeof topQueriesData[0]> = [
    {
      title: "Query",
      dataIndex: "query",
      key: "query",
      ellipsis: true,
      render: (query: string, record) => (
        <div>
          <div
            style={{
              fontFamily: "monospace",
              fontSize: "12px",
              color: "#0f172a",
              marginBottom: "4px",
            }}
          >
            {query}
          </div>
          <div style={{ fontSize: "11px", color: "#64748b" }}>{record.database}</div>
        </div>
      ),
    },
    {
      title: "Executions",
      dataIndex: "executions",
      key: "executions",
      align: "right",
      sorter: (a, b) => a.executions - b.executions,
      render: (count: number) => <span style={{ fontWeight: 600 }}>{count.toLocaleString()}</span>,
    },
    {
      title: "Avg Duration (ms)",
      dataIndex: "avgDuration",
      key: "avgDuration",
      align: "right",
      sorter: (a, b) => a.avgDuration - b.avgDuration,
      render: (duration: number) => (
        <span
          style={{
            fontWeight: 600,
            color: duration > 500 ? "#dc2626" : duration > 200 ? "#f59e0b" : "#16a34a",
          }}
        >
          {duration}
        </span>
      ),
    },
    {
      title: "Total Time",
      dataIndex: "totalTime",
      key: "totalTime",
      align: "right",
    },
  ];

  return (
    <div>
      <div style={{ marginBottom: "24px", display: "flex", justifyContent: "space-between" }}>
        <div>
          <h1 style={{ fontSize: "28px", fontWeight: 700, marginBottom: "8px" }}>
            Analytics & Reports
          </h1>
          <p style={{ color: "#64748b", fontSize: "14px" }}>
            Comprehensive insights into security trends and database performance
          </p>
        </div>
        <Space>
          <RangePicker />
          <Select defaultValue="7d" style={{ width: 120 }}>
            <Select.Option value="24h">Last 24h</Select.Option>
            <Select.Option value="7d">Last 7 days</Select.Option>
            <Select.Option value="30d">Last 30 days</Select.Option>
            <Select.Option value="90d">Last 90 days</Select.Option>
          </Select>
          <Button type="primary" icon={<DownloadOutlined />}>
            Export Report
          </Button>
        </Space>
      </div>

      {/* Summary Statistics */}
      <Row gutter={[16, 16]} style={{ marginBottom: "24px" }}>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Total Incidents"
              value={215}
              valueStyle={{ color: "#3b82f6" }}
              suffix={
                <span style={{ fontSize: "14px", color: "#16a34a" }}>
                  <ArrowDownOutlined /> 12%
                </span>
              }
            />
            <div style={{ marginTop: "8px", fontSize: "12px", color: "#64748b" }}>
              vs. previous period
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Avg Resolution Time"
              value={4.2}
              suffix="hours"
              valueStyle={{ color: "#16a34a" }}
              prefix={
                <span style={{ fontSize: "14px", color: "#16a34a" }}>
                  <ArrowDownOutlined />
                </span>
              }
            />
            <div style={{ marginTop: "8px", fontSize: "12px", color: "#64748b" }}>
              Improved by 23%
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="False Positive Rate"
              value={8.4}
              suffix="%"
              valueStyle={{ color: "#f59e0b" }}
              prefix={
                <span style={{ fontSize: "14px", color: "#dc2626" }}>
                  <ArrowUpOutlined />
                </span>
              }
            />
            <div style={{ marginTop: "8px", fontSize: "12px", color: "#64748b" }}>
              Needs improvement
            </div>
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Critical Alerts"
              value={27}
              valueStyle={{ color: "#dc2626" }}
              suffix={
                <span style={{ fontSize: "14px", color: "#dc2626" }}>
                  <ArrowUpOutlined /> 34%
                </span>
              }
            />
            <div style={{ marginTop: "8px", fontSize: "12px", color: "#64748b" }}>
              Requires attention
            </div>
          </Card>
        </Col>
      </Row>

      {/* Charts Row 1 */}
      <Row gutter={[16, 16]} style={{ marginBottom: "24px" }}>
        <Col xs={24} lg={16}>
          <Card title="Alert Trends by Severity" styles={{ body: { paddingTop: "16px" } }}>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={alertTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="month" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="critical"
                  stackId="1"
                  stroke="#dc2626"
                  fill="#dc2626"
                  fillOpacity={0.8}
                  name="Critical"
                />
                <Area
                  type="monotone"
                  dataKey="high"
                  stackId="1"
                  stroke="#ea580c"
                  fill="#ea580c"
                  fillOpacity={0.7}
                  name="High"
                />
                <Area
                  type="monotone"
                  dataKey="medium"
                  stackId="1"
                  stroke="#f59e0b"
                  fill="#f59e0b"
                  fillOpacity={0.6}
                  name="Medium"
                />
                <Area
                  type="monotone"
                  dataKey="low"
                  stackId="1"
                  stroke="#3b82f6"
                  fill="#3b82f6"
                  fillOpacity={0.5}
                  name="Low"
                />
              </AreaChart>
            </ResponsiveContainer>
          </Card>
        </Col>

        <Col xs={24} lg={8}>
          <Card title="Event Type Distribution" styles={{ body: { paddingTop: "16px" } }}>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={eventTypeDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {eventTypeDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </Col>
      </Row>

      {/* Charts Row 2 */}
      <Row gutter={[16, 16]} style={{ marginBottom: "24px" }}>
        <Col xs={24} lg={12}>
          <Card title="Database Activity by Hour" styles={{ body: { paddingTop: "16px" } }}>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={databaseActivityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="hour" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="production_db"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  name="Production DB"
                />
                <Line
                  type="monotone"
                  dataKey="auth_db"
                  stroke="#8b5cf6"
                  strokeWidth={2}
                  name="Auth DB"
                />
                <Line
                  type="monotone"
                  dataKey="customer_db"
                  stroke="#10b981"
                  strokeWidth={2}
                  name="Customer DB"
                />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </Col>

        <Col xs={24} lg={12}>
          <Card title="Incident Resolution Trends" styles={{ body: { paddingTop: "16px" } }}>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={incidentResolutionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="week" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip />
                <Legend />
                <Bar dataKey="resolved" fill="#10b981" name="Resolved" />
                <Bar dataKey="investigating" fill="#f59e0b" name="Investigating" />
                <Bar dataKey="unreviewed" fill="#dc2626" name="Unreviewed" />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </Col>
      </Row>

      {/* Top Queries Table */}
      <Card title="Top Queries by Execution Count">
        <Table
          columns={queryColumns}
          dataSource={topQueriesData}
          pagination={false}
          size="small"
        />
      </Card>
    </div>
  );
}
