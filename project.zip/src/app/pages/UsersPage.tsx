import { useState } from "react";
import {
  Card,
  Table,
  Tag,
  Progress,
  Button,
  Space,
  Input,
  Select,
  Drawer,
  Timeline,
  Statistic,
  Row,
  Col,
  Badge,
  Divider,
} from "antd";
import {
  SearchOutlined,
  WarningOutlined,
  UserOutlined,
  EyeOutlined,
} from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";

const { TextArea } = Input;

interface UserRiskProfile {
  key: string;
  username: string;
  email: string;
  role: string;
  riskScore: number;
  riskLevel: "critical" | "high" | "medium" | "low";
  totalEvents: number;
  alertsTriggered: number;
  failedLogins: number;
  privilegedOps: number;
  dataExported: string;
  lastActivity: string;
  status: "active" | "suspended" | "monitored";
}

const mockUsers: UserRiskProfile[] = [
  {
    key: "1",
    username: "john.doe",
    email: "john.doe@company.com",
    role: "Data Analyst",
    riskScore: 87,
    riskLevel: "critical",
    totalEvents: 1543,
    alertsTriggered: 12,
    failedLogins: 0,
    privilegedOps: 23,
    dataExported: "8.3 GB",
    lastActivity: "5 min ago",
    status: "monitored",
  },
  {
    key: "2",
    username: "sys_admin",
    email: "sysadmin@company.com",
    role: "System Administrator",
    riskScore: 72,
    riskLevel: "high",
    totalEvents: 2341,
    alertsTriggered: 8,
    failedLogins: 0,
    privilegedOps: 156,
    dataExported: "1.2 GB",
    lastActivity: "1 hour ago",
    status: "active",
  },
  {
    key: "3",
    username: "db_operator",
    email: "dbops@company.com",
    role: "Database Operator",
    riskScore: 65,
    riskLevel: "high",
    totalEvents: 3214,
    alertsTriggered: 7,
    failedLogins: 2,
    privilegedOps: 89,
    dataExported: "3.4 GB",
    lastActivity: "2 hours ago",
    status: "monitored",
  },
  {
    key: "4",
    username: "admin_user",
    email: "admin@company.com",
    role: "Administrator",
    riskScore: 58,
    riskLevel: "medium",
    totalEvents: 892,
    alertsTriggered: 5,
    failedLogins: 0,
    privilegedOps: 67,
    dataExported: "567 MB",
    lastActivity: "3 hours ago",
    status: "active",
  },
  {
    key: "5",
    username: "api_service",
    email: "api@company.com",
    role: "Service Account",
    riskScore: 45,
    riskLevel: "medium",
    totalEvents: 15234,
    alertsTriggered: 3,
    failedLogins: 5,
    privilegedOps: 0,
    dataExported: "12.5 GB",
    lastActivity: "1 min ago",
    status: "active",
  },
  {
    key: "6",
    username: "data_scientist",
    email: "datascience@company.com",
    role: "Data Scientist",
    riskScore: 38,
    riskLevel: "medium",
    totalEvents: 567,
    alertsTriggered: 2,
    failedLogins: 0,
    privilegedOps: 12,
    dataExported: "4.2 GB",
    lastActivity: "6 hours ago",
    status: "active",
  },
  {
    key: "7",
    username: "readonly_user",
    email: "readonly@company.com",
    role: "Analyst",
    riskScore: 15,
    riskLevel: "low",
    totalEvents: 234,
    alertsTriggered: 0,
    failedLogins: 0,
    privilegedOps: 0,
    dataExported: "89 MB",
    lastActivity: "1 day ago",
    status: "active",
  },
];

export function UsersPage() {
  const [selectedUser, setSelectedUser] = useState<UserRiskProfile | null>(null);
  const [drawerVisible, setDrawerVisible] = useState(false);

  const columns: ColumnsType<UserRiskProfile> = [
    {
      title: "User",
      key: "user",
      fixed: "left",
      width: 200,
      render: (_, record) => (
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <UserOutlined style={{ color: "#64748b" }} />
            <span style={{ fontWeight: 600 }}>{record.username}</span>
          </div>
          <div style={{ fontSize: "12px", color: "#64748b", marginTop: "2px" }}>
            {record.email}
          </div>
        </div>
      ),
    },
    {
      title: "Role",
      dataIndex: "role",
      key: "role",
      width: 150,
    },
    {
      title: "Risk Score",
      key: "riskScore",
      width: 200,
      sorter: (a, b) => a.riskScore - b.riskScore,
      render: (_, record) => (
        <div>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginBottom: "4px",
            }}
          >
            <span style={{ fontWeight: 600 }}>{record.riskScore}</span>
            <Tag
              color={
                record.riskLevel === "critical"
                  ? "red"
                  : record.riskLevel === "high"
                  ? "orange"
                  : record.riskLevel === "medium"
                  ? "gold"
                  : "green"
              }
              style={{ fontSize: "11px" }}
            >
              {record.riskLevel.toUpperCase()}
            </Tag>
          </div>
          <Progress
            percent={record.riskScore}
            strokeColor={
              record.riskScore > 70
                ? "#dc2626"
                : record.riskScore > 50
                ? "#f59e0b"
                : record.riskScore > 30
                ? "#3b82f6"
                : "#16a34a"
            }
            showInfo={false}
            size="small"
          />
        </div>
      ),
    },
    {
      title: "Total Events",
      dataIndex: "totalEvents",
      key: "totalEvents",
      align: "right",
      sorter: (a, b) => a.totalEvents - b.totalEvents,
      render: (count: number) => <span style={{ fontWeight: 600 }}>{count.toLocaleString()}</span>,
    },
    {
      title: "Alerts",
      dataIndex: "alertsTriggered",
      key: "alertsTriggered",
      align: "center",
      sorter: (a, b) => a.alertsTriggered - b.alertsTriggered,
      render: (count: number) => (
        <Badge
          count={count}
          showZero
          style={{
            backgroundColor: count > 5 ? "#dc2626" : count > 0 ? "#f59e0b" : "#94a3b8",
          }}
        />
      ),
    },
    {
      title: "Failed Logins",
      dataIndex: "failedLogins",
      key: "failedLogins",
      align: "center",
      sorter: (a, b) => a.failedLogins - b.failedLogins,
      render: (count: number) => (
        <span style={{ color: count > 0 ? "#dc2626" : "#64748b", fontWeight: 600 }}>
          {count}
        </span>
      ),
    },
    {
      title: "Privileged Ops",
      dataIndex: "privilegedOps",
      key: "privilegedOps",
      align: "center",
      sorter: (a, b) => a.privilegedOps - b.privilegedOps,
      render: (count: number) => (
        <span style={{ color: count > 50 ? "#f59e0b" : "#64748b", fontWeight: 600 }}>
          {count}
        </span>
      ),
    },
    {
      title: "Data Exported",
      dataIndex: "dataExported",
      key: "dataExported",
      align: "right",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 110,
      filters: [
        { text: "Active", value: "active" },
        { text: "Monitored", value: "monitored" },
        { text: "Suspended", value: "suspended" },
      ],
      onFilter: (value, record) => record.status === value,
      render: (status: string) => {
        const statusConfig = {
          active: { color: "green", text: "Active" },
          monitored: { color: "orange", text: "Monitored" },
          suspended: { color: "red", text: "Suspended" },
        };
        const config = statusConfig[status as keyof typeof statusConfig];
        return <Tag color={config.color}>{config.text}</Tag>;
      },
    },
    {
      title: "Actions",
      key: "actions",
      fixed: "right",
      width: 100,
      render: (_, record) => (
        <Button
          type="link"
          size="small"
          icon={<EyeOutlined />}
          onClick={() => {
            setSelectedUser(record);
            setDrawerVisible(true);
          }}
        >
          View
        </Button>
      ),
    },
  ];

  return (
    <div>
      <div style={{ marginBottom: "24px" }}>
        <h1 style={{ fontSize: "28px", fontWeight: 700, marginBottom: "8px" }}>
          User Risk Profiles
        </h1>
        <p style={{ color: "#64748b", fontSize: "14px" }}>
          Monitor user behavior and identify high-risk accounts
        </p>
      </div>

      {/* Summary Statistics */}
      <Row gutter={[16, 16]} style={{ marginBottom: "24px" }}>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Total Users"
              value={mockUsers.length}
              prefix={<UserOutlined />}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="High Risk Users"
              value={mockUsers.filter((u) => u.riskScore > 60).length}
              valueStyle={{ color: "#dc2626" }}
              prefix={<WarningOutlined />}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Monitored Accounts"
              value={mockUsers.filter((u) => u.status === "monitored").length}
              valueStyle={{ color: "#f59e0b" }}
            />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card>
            <Statistic
              title="Total Alerts"
              value={mockUsers.reduce((sum, u) => sum + u.alertsTriggered, 0)}
              valueStyle={{ color: "#3b82f6" }}
            />
          </Card>
        </Col>
      </Row>

      {/* Filters */}
      <Card style={{ marginBottom: "24px" }}>
        <Space wrap>
          <Input
            placeholder="Search users..."
            prefix={<SearchOutlined />}
            style={{ width: 250 }}
          />
          <Select defaultValue="all" style={{ width: 150 }}>
            <Select.Option value="all">All Risk Levels</Select.Option>
            <Select.Option value="critical">Critical</Select.Option>
            <Select.Option value="high">High</Select.Option>
            <Select.Option value="medium">Medium</Select.Option>
            <Select.Option value="low">Low</Select.Option>
          </Select>
          <Select defaultValue="all" style={{ width: 150 }}>
            <Select.Option value="all">All Statuses</Select.Option>
            <Select.Option value="active">Active</Select.Option>
            <Select.Option value="monitored">Monitored</Select.Option>
            <Select.Option value="suspended">Suspended</Select.Option>
          </Select>
          <Select defaultValue="all" style={{ width: 180 }}>
            <Select.Option value="all">All Roles</Select.Option>
            <Select.Option value="admin">Administrator</Select.Option>
            <Select.Option value="analyst">Analyst</Select.Option>
            <Select.Option value="service">Service Account</Select.Option>
          </Select>
        </Space>
      </Card>

      {/* Users Table */}
      <Card>
        <Table
          columns={columns}
          dataSource={mockUsers}
          pagination={{ pageSize: 10, showSizeChanger: true }}
          scroll={{ x: 1400 }}
        />
      </Card>

      {/* User Details Drawer */}
      <Drawer
        title="User Risk Profile"
        placement="right"
        width={600}
        onClose={() => setDrawerVisible(false)}
        open={drawerVisible}
      >
        {selectedUser && (
          <div>
            <div style={{ marginBottom: "24px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
                <UserOutlined style={{ fontSize: "32px", color: "#3b82f6" }} />
                <div>
                  <h2 style={{ fontSize: "20px", fontWeight: 700, marginBottom: "4px" }}>
                    {selectedUser.username}
                  </h2>
                  <div style={{ color: "#64748b", fontSize: "14px" }}>
                    {selectedUser.email} • {selectedUser.role}
                  </div>
                </div>
              </div>
            </div>

            <Row gutter={[16, 16]} style={{ marginBottom: "24px" }}>
              <Col span={12}>
                <Card size="small">
                  <Statistic
                    title="Risk Score"
                    value={selectedUser.riskScore}
                    valueStyle={{
                      color:
                        selectedUser.riskScore > 70
                          ? "#dc2626"
                          : selectedUser.riskScore > 50
                          ? "#f59e0b"
                          : "#3b82f6",
                    }}
                  />
                  <Progress
                    percent={selectedUser.riskScore}
                    strokeColor={
                      selectedUser.riskScore > 70
                        ? "#dc2626"
                        : selectedUser.riskScore > 50
                        ? "#f59e0b"
                        : "#3b82f6"
                    }
                    showInfo={false}
                    style={{ marginTop: "8px" }}
                  />
                </Card>
              </Col>
              <Col span={12}>
                <Card size="small">
                  <Statistic
                    title="Alerts Triggered"
                    value={selectedUser.alertsTriggered}
                    valueStyle={{ color: "#dc2626" }}
                  />
                </Card>
              </Col>
            </Row>

            <Divider />

            <div style={{ marginBottom: "24px" }}>
              <h3 style={{ fontSize: "14px", fontWeight: 600, marginBottom: "12px" }}>
                Activity Summary
              </h3>
              <Space direction="vertical" style={{ width: "100%" }}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: "#64748b" }}>Total Events:</span>
                  <span style={{ fontWeight: 600 }}>
                    {selectedUser.totalEvents.toLocaleString()}
                  </span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: "#64748b" }}>Failed Logins:</span>
                  <span style={{ fontWeight: 600, color: "#dc2626" }}>
                    {selectedUser.failedLogins}
                  </span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: "#64748b" }}>Privileged Operations:</span>
                  <span style={{ fontWeight: 600, color: "#f59e0b" }}>
                    {selectedUser.privilegedOps}
                  </span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: "#64748b" }}>Data Exported:</span>
                  <span style={{ fontWeight: 600 }}>{selectedUser.dataExported}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: "#64748b" }}>Last Activity:</span>
                  <span style={{ fontWeight: 600 }}>{selectedUser.lastActivity}</span>
                </div>
              </Space>
            </div>

            <Card
              title="🤖 AI Risk Assessment"
              size="small"
              style={{ marginBottom: "24px", background: "#fef3c7" }}
            >
              <p style={{ marginBottom: "12px" }}>
                This user exhibits {selectedUser.riskLevel} risk behavior based on:
              </p>
              <ul style={{ marginBottom: 0, paddingLeft: "20px" }}>
                {selectedUser.alertsTriggered > 5 && (
                  <li>Multiple security alerts triggered recently</li>
                )}
                {selectedUser.privilegedOps > 50 && (
                  <li>High volume of privileged operations</li>
                )}
                {selectedUser.dataExported.includes("GB") && (
                  <li>Significant data export activity</li>
                )}
                <li>Activity pattern deviates from baseline by 45%</li>
              </ul>
            </Card>

            <div style={{ marginBottom: "24px" }}>
              <h3 style={{ fontSize: "14px", fontWeight: 600, marginBottom: "12px" }}>
                Recent Activity
              </h3>
              <Timeline
                items={[
                  {
                    color: "red",
                    children: (
                      <div>
                        <div style={{ fontWeight: 600 }}>Unusual data export detected</div>
                        <div style={{ fontSize: "12px", color: "#64748b" }}>
                          2 hours ago • production_db
                        </div>
                      </div>
                    ),
                  },
                  {
                    color: "blue",
                    children: (
                      <div>
                        <div style={{ fontWeight: 600 }}>Successful login</div>
                        <div style={{ fontSize: "12px", color: "#64748b" }}>
                          5 hours ago • IP: 192.168.1.100
                        </div>
                      </div>
                    ),
                  },
                  {
                    color: "orange",
                    children: (
                      <div>
                        <div style={{ fontWeight: 600 }}>Privileged operation executed</div>
                        <div style={{ fontSize: "12px", color: "#64748b" }}>
                          1 day ago • customer_db
                        </div>
                      </div>
                    ),
                  },
                ]}
              />
            </div>

            <Space direction="vertical" style={{ width: "100%" }}>
              <Button type="primary" danger block>
                Suspend Account
              </Button>
              <Button block>Add to Monitoring List</Button>
              <Button block>View Full Activity Log</Button>
            </Space>
          </div>
        )}
      </Drawer>
    </div>
  );
}
