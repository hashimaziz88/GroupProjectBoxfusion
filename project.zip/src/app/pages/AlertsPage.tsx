import { useState } from "react";
import {
  Card,
  Table,
  Tag,
  Button,
  Space,
  Select,
  Input,
  DatePicker,
  Modal,
  Form,
  Drawer,
  Badge,
  Timeline,
  Typography,
  Divider,
} from "antd";
import {
  SearchOutlined,
  FilterOutlined,
  ExportOutlined,
  CheckCircleOutlined,
  CloseCircleOutlined,
  EyeOutlined,
} from "@ant-design/icons";
import type { ColumnsType } from "antd/es/table";

const { RangePicker } = DatePicker;
const { TextArea } = Input;
const { Text, Paragraph } = Typography;

interface AlertData {
  key: string;
  id: string;
  severity: "critical" | "high" | "medium" | "low";
  title: string;
  description: string;
  database: string;
  table: string;
  user: string;
  timestamp: string;
  status: "unreviewed" | "investigating" | "resolved" | "false_positive";
  aiSummary: string;
  riskScore: number;
}

const mockAlerts: AlertData[] = [
  {
    key: "1",
    id: "ALT-2024-0316-001",
    severity: "critical",
    title: "Unusual data export volume detected",
    description: "User exported 2.3GB of customer data in a single query",
    database: "production_db",
    table: "customers",
    user: "john.doe",
    timestamp: "2024-03-16 14:23:15",
    status: "unreviewed",
    aiSummary:
      "This activity represents a 450% increase from the user's baseline. The export occurred outside normal business hours and accessed PII data. High probability of data exfiltration attempt.",
    riskScore: 92,
  },
  {
    key: "2",
    id: "ALT-2024-0316-002",
    severity: "high",
    title: "Failed login attempts spike",
    description: "89 failed login attempts from single IP in 5 minutes",
    database: "auth_db",
    table: "user_sessions",
    user: "unknown",
    timestamp: "2024-03-16 14:08:42",
    status: "investigating",
    aiSummary:
      "Pattern indicates brute force attack. IP address 192.168.1.45 attempted dictionary-based password guessing. Recommend IP blocking and password reset notifications.",
    riskScore: 87,
  },
  {
    key: "3",
    id: "ALT-2024-0316-003",
    severity: "medium",
    title: "Out-of-hours database access",
    description: "Database accessed at 2:45 AM on Sunday",
    database: "customer_db",
    table: "orders",
    user: "admin_user",
    timestamp: "2024-03-16 02:45:18",
    status: "unreviewed",
    aiSummary:
      "User accessed sensitive order data during unusual hours. While admin_user has appropriate permissions, the timing is suspicious. Verify if this was authorized maintenance.",
    riskScore: 65,
  },
  {
    key: "4",
    id: "ALT-2024-0316-004",
    severity: "high",
    title: "Privileged operation without approval",
    description: "DROP TABLE command executed without approval ticket",
    database: "production_db",
    table: "temp_analytics",
    user: "sys_admin",
    timestamp: "2024-03-16 11:15:33",
    status: "resolved",
    aiSummary:
      "Privileged DDL operation detected. User has appropriate role but change management process was bypassed. Table was a temporary analytics table with no production data.",
    riskScore: 78,
  },
  {
    key: "5",
    id: "ALT-2024-0316-005",
    severity: "critical",
    title: "Suspicious query pattern detected",
    description: "Query extracted entire user table with passwords",
    database: "auth_db",
    table: "users",
    user: "db_operator",
    timestamp: "2024-03-16 09:34:22",
    status: "unreviewed",
    aiSummary:
      "SELECT query accessed password hash column which is rarely accessed. Query pattern matches known credential dumping techniques. Immediate investigation recommended.",
    riskScore: 95,
  },
  {
    key: "6",
    id: "ALT-2024-0316-006",
    severity: "medium",
    title: "Excessive read operations",
    description: "User performed 15,000 SELECT queries in 10 minutes",
    database: "production_db",
    table: "products",
    user: "api_service",
    timestamp: "2024-03-16 13:20:45",
    status: "false_positive",
    aiSummary:
      "High volume of read operations detected. Investigation revealed this was legitimate API traffic spike from marketing campaign. Pattern normalized after campaign ended.",
    riskScore: 45,
  },
];

export function AlertsPage() {
  const [selectedAlert, setSelectedAlert] = useState<AlertData | null>(null);
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [statusModalVisible, setStatusModalVisible] = useState(false);
  const [filters, setFilters] = useState({
    severity: "all",
    status: "all",
    database: "all",
  });

  const columns: ColumnsType<AlertData> = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
      width: 150,
      render: (text) => (
        <Text code style={{ fontSize: "11px" }}>
          {text}
        </Text>
      ),
    },
    {
      title: "Severity",
      dataIndex: "severity",
      key: "severity",
      width: 100,
      filters: [
        { text: "Critical", value: "critical" },
        { text: "High", value: "high" },
        { text: "Medium", value: "medium" },
        { text: "Low", value: "low" },
      ],
      onFilter: (value, record) => record.severity === value,
      render: (severity: string) => {
        const colors = {
          critical: { color: "#dc2626", bg: "#fee2e2" },
          high: { color: "#ea580c", bg: "#ffedd5" },
          medium: { color: "#f59e0b", bg: "#fef3c7" },
          low: { color: "#3b82f6", bg: "#dbeafe" },
        };
        const style = colors[severity as keyof typeof colors];
        return (
          <Tag
            color={style.color}
            style={{
              background: style.bg,
              border: "none",
              fontWeight: 600,
              textTransform: "uppercase",
              fontSize: "11px",
            }}
          >
            {severity}
          </Tag>
        );
      },
    },
    {
      title: "Alert Details",
      key: "details",
      render: (_, record) => (
        <div>
          <div style={{ fontWeight: 600, color: "#0f172a", marginBottom: "4px" }}>
            {record.title}
          </div>
          <div style={{ fontSize: "12px", color: "#64748b" }}>
            {record.description}
          </div>
          <div style={{ fontSize: "11px", color: "#94a3b8", marginTop: "4px" }}>
            {record.database} • {record.table} • {record.user}
          </div>
        </div>
      ),
    },
    {
      title: "Risk Score",
      dataIndex: "riskScore",
      key: "riskScore",
      width: 100,
      sorter: (a, b) => a.riskScore - b.riskScore,
      render: (score: number) => (
        <Badge
          count={score}
          style={{
            backgroundColor: score > 80 ? "#dc2626" : score > 60 ? "#f59e0b" : "#3b82f6",
          }}
        />
      ),
    },
    {
      title: "Time",
      dataIndex: "timestamp",
      key: "timestamp",
      width: 160,
      sorter: (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime(),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      width: 130,
      filters: [
        { text: "Unreviewed", value: "unreviewed" },
        { text: "Investigating", value: "investigating" },
        { text: "Resolved", value: "resolved" },
        { text: "False Positive", value: "false_positive" },
      ],
      onFilter: (value, record) => record.status === value,
      render: (status: string) => {
        const statusConfig = {
          unreviewed: { color: "red", text: "Unreviewed" },
          investigating: { color: "orange", text: "Investigating" },
          resolved: { color: "green", text: "Resolved" },
          false_positive: { color: "default", text: "False Positive" },
        };
        const config = statusConfig[status as keyof typeof statusConfig];
        return <Tag color={config.color}>{config.text}</Tag>;
      },
    },
    {
      title: "Actions",
      key: "actions",
      width: 100,
      render: (_, record) => (
        <Button
          type="link"
          size="small"
          icon={<EyeOutlined />}
          onClick={() => {
            setSelectedAlert(record);
            setDrawerVisible(true);
          }}
        >
          View
        </Button>
      ),
    },
  ];

  const handleStatusChange = (values: any) => {
    console.log("Status updated:", values);
    setStatusModalVisible(false);
  };

  return (
    <div>
      <div style={{ marginBottom: "24px" }}>
        <h1 style={{ fontSize: "28px", fontWeight: 700, marginBottom: "8px" }}>
          Security Alerts
        </h1>
        <p style={{ color: "#64748b", fontSize: "14px" }}>
          Monitor and investigate security anomalies and suspicious activities
        </p>
      </div>

      {/* Filters */}
      <Card style={{ marginBottom: "24px" }}>
        <Space wrap style={{ width: "100%" }}>
          <Input
            placeholder="Search alerts..."
            prefix={<SearchOutlined />}
            style={{ width: 250 }}
          />
          <Select
            defaultValue="all"
            style={{ width: 150 }}
            onChange={(value) => setFilters({ ...filters, severity: value })}
          >
            <Select.Option value="all">All Severities</Select.Option>
            <Select.Option value="critical">Critical</Select.Option>
            <Select.Option value="high">High</Select.Option>
            <Select.Option value="medium">Medium</Select.Option>
            <Select.Option value="low">Low</Select.Option>
          </Select>
          <Select
            defaultValue="all"
            style={{ width: 150 }}
            onChange={(value) => setFilters({ ...filters, status: value })}
          >
            <Select.Option value="all">All Statuses</Select.Option>
            <Select.Option value="unreviewed">Unreviewed</Select.Option>
            <Select.Option value="investigating">Investigating</Select.Option>
            <Select.Option value="resolved">Resolved</Select.Option>
          </Select>
          <Select
            defaultValue="all"
            style={{ width: 180 }}
            onChange={(value) => setFilters({ ...filters, database: value })}
          >
            <Select.Option value="all">All Databases</Select.Option>
            <Select.Option value="production_db">production_db</Select.Option>
            <Select.Option value="auth_db">auth_db</Select.Option>
            <Select.Option value="customer_db">customer_db</Select.Option>
          </Select>
          <RangePicker />
          <Button icon={<FilterOutlined />}>More Filters</Button>
          <Button type="primary" icon={<ExportOutlined />}>
            Export Report
          </Button>
        </Space>
      </Card>

      {/* Alerts Table */}
      <Card>
        <Table
          columns={columns}
          dataSource={mockAlerts}
          pagination={{ pageSize: 10, showSizeChanger: true }}
        />
      </Card>

      {/* Alert Details Drawer */}
      <Drawer
        title="Alert Details"
        placement="right"
        width={600}
        onClose={() => setDrawerVisible(false)}
        open={drawerVisible}
      >
        {selectedAlert && (
          <div>
            <div style={{ marginBottom: "24px" }}>
              <Space>
                <Tag
                  color={
                    selectedAlert.severity === "critical"
                      ? "#dc2626"
                      : selectedAlert.severity === "high"
                      ? "#ea580c"
                      : "#f59e0b"
                  }
                  style={{
                    background:
                      selectedAlert.severity === "critical"
                        ? "#fee2e2"
                        : selectedAlert.severity === "high"
                        ? "#ffedd5"
                        : "#fef3c7",
                    border: "none",
                    fontWeight: 600,
                    textTransform: "uppercase",
                  }}
                >
                  {selectedAlert.severity}
                </Tag>
                <Badge
                  count={selectedAlert.riskScore}
                  style={{
                    backgroundColor:
                      selectedAlert.riskScore > 80
                        ? "#dc2626"
                        : selectedAlert.riskScore > 60
                        ? "#f59e0b"
                        : "#3b82f6",
                  }}
                />
              </Space>
              <h2 style={{ fontSize: "20px", fontWeight: 700, marginTop: "16px" }}>
                {selectedAlert.title}
              </h2>
              <Text type="secondary">{selectedAlert.id}</Text>
            </div>

            <Divider />

            <div style={{ marginBottom: "24px" }}>
              <h3 style={{ fontSize: "14px", fontWeight: 600, marginBottom: "8px" }}>
                Description
              </h3>
              <Paragraph>{selectedAlert.description}</Paragraph>
            </div>

            <div style={{ marginBottom: "24px" }}>
              <h3 style={{ fontSize: "14px", fontWeight: 600, marginBottom: "12px" }}>
                Event Details
              </h3>
              <Space direction="vertical" style={{ width: "100%" }}>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <Text type="secondary">Database:</Text>
                  <Text strong>{selectedAlert.database}</Text>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <Text type="secondary">Table:</Text>
                  <Text strong>{selectedAlert.table}</Text>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <Text type="secondary">User:</Text>
                  <Text strong>{selectedAlert.user}</Text>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <Text type="secondary">Timestamp:</Text>
                  <Text strong>{selectedAlert.timestamp}</Text>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <Text type="secondary">Current Status:</Text>
                  <Tag color={selectedAlert.status === "unreviewed" ? "red" : "blue"}>
                    {selectedAlert.status}
                  </Tag>
                </div>
              </Space>
            </div>

            <Card
              title="🤖 AI Analysis"
              size="small"
              style={{ marginBottom: "24px", background: "#f0f9ff" }}
            >
              <Paragraph style={{ marginBottom: 0 }}>
                {selectedAlert.aiSummary}
              </Paragraph>
            </Card>

            <div style={{ marginBottom: "24px" }}>
              <h3 style={{ fontSize: "14px", fontWeight: 600, marginBottom: "12px" }}>
                Recommended Actions
              </h3>
              <Timeline
                items={[
                  {
                    children: "Review user activity history for patterns",
                    color: "blue",
                  },
                  {
                    children: "Verify if activity was authorized",
                    color: "blue",
                  },
                  {
                    children: "Contact user or their manager",
                    color: "blue",
                  },
                  {
                    children: "Update alert status and add notes",
                    color: "blue",
                  },
                ]}
              />
            </div>

            <Space style={{ width: "100%" }} direction="vertical">
              <Button
                type="primary"
                block
                onClick={() => setStatusModalVisible(true)}
              >
                Update Status
              </Button>
              <Button block icon={<ExportOutlined />}>
                Export Incident Report
              </Button>
            </Space>
          </div>
        )}
      </Drawer>

      {/* Status Update Modal */}
      <Modal
        title="Update Alert Status"
        open={statusModalVisible}
        onCancel={() => setStatusModalVisible(false)}
        footer={null}
      >
        <Form layout="vertical" onFinish={handleStatusChange}>
          <Form.Item label="New Status" name="status" required>
            <Select>
              <Select.Option value="investigating">
                <CheckCircleOutlined /> Investigating
              </Select.Option>
              <Select.Option value="resolved">
                <CheckCircleOutlined /> Resolved
              </Select.Option>
              <Select.Option value="false_positive">
                <CloseCircleOutlined /> False Positive
              </Select.Option>
            </Select>
          </Form.Item>
          <Form.Item label="Notes" name="notes">
            <TextArea rows={4} placeholder="Add investigation notes..." />
          </Form.Item>
          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit">
                Update
              </Button>
              <Button onClick={() => setStatusModalVisible(false)}>Cancel</Button>
            </Space>
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}
